#!/usr/bin/env python3
"""
Simple wrapper for OnlineComponentsDatamodule that loads configuration from YAML.
This provides a cleaner interface while keeping all the existing functionality.
"""

import os
import random
from pathlib import Path
from typing import Any, Dict, Optional, Union
import yaml
import torch

from .datamodule import OnlineComponentsDatamodule


def create_datamodule_from_config(
    config_path: Union[str, Path],
    **override_kwargs
) -> OnlineComponentsDatamodule:
    """
    Create an OnlineComponentsDatamodule from a YAML configuration file.
    
    This is a simple factory function that loads the YAML config and creates
    the datamodule with the specified parameters.
    
    Args:
        config_path: Path to the YAML configuration file
        **override_kwargs: Additional arguments to override config values
        
    Returns:
        Configured OnlineComponentsDatamodule instance
    """
    # Load configuration
    config_path = Path(config_path)
    if not config_path.exists():
        raise FileNotFoundError(f"Configuration file not found: {config_path}")
    
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Override config with any provided kwargs
    config.update(override_kwargs)
    
    # Set up paths
    root = Path(config['data']['root'])
    val_root = Path(config['data']['val_root'])
    
    # Handle environment variable for val_root
    if 'DATADIR' in os.environ:
        val_root = Path(os.environ['DATADIR']) / 'synthetic'
    
    # Extract datamodule configuration
    dm_config = config['datamodule']
    
    # Set up random seed
    seed = dm_config.get('seed')
    if seed is None:
        seed = random.randint(0, 10000)
    
    # Create the datamodule with all the configuration
    dm = OnlineComponentsDatamodule(
        root=root,
        val_root=val_root,
        num_samples=dm_config['num_samples'],
        img_res=dm_config['image_size'][0],  # Assuming square images
        bg_color_sampler_dict=config['bg_color_sampler'],
        use_worley_sampler=dm_config['use_worley_sampler'],
        use_grf_sampler=dm_config['use_grf_sampler'],
        worley_sampler_dict=config['worley_sampler'],
        mandelbulb_sampler=config['mandelbulb_sampler'],
        batch_size=dm_config['batch_size'],
        num_workers=dm_config['num_workers'],
        shuffle=dm_config['shuffle'],
        seed=seed,
        shaders=config['shaders'],
    )
    
    dm.setup_for_gpu_once(torch.device(f'cuda:{torch.cuda.current_device()}'))
    dm.post_init()
    dm.setup('fit')
    
    print(f"Dataset length: {len(dm.train_data)}")
    print(f"Batch size: {dm.batch_size}")
    
    return dm


# For backward compatibility, also provide a class-based interface
class OnlineSynthDatamodule(OnlineComponentsDatamodule):
    """
    Simple wrapper around OnlineComponentsDatamodule that loads config from YAML.
    
    This class just adds YAML config loading to the existing datamodule.
    All other functionality remains the same.
    """
    
    def __init__(
        self,
        config_path: Union[str, Path],
        **override_kwargs
    ):
        """
        Initialize the datamodule with configuration from YAML file.
        
        Args:
            config_path: Path to the YAML configuration file
            **override_kwargs: Additional arguments to override config values
        """
        # Load configuration
        config_path = Path(config_path)
        if not config_path.exists():
            raise FileNotFoundError(f"Configuration file not found: {config_path}")
        
        with open(config_path, 'r') as f:
            config = yaml.safe_load(f)
        
        # Override config with any provided kwargs
        config.update(override_kwargs)
        
        # Set up paths
        root = Path(config['data']['root'])
        val_root = Path(config['data']['val_root'])
        
        # Handle environment variable for val_root
        if 'DATADIR' in os.environ:
            val_root = Path(os.environ['DATADIR']) / 'synthetic'
        
        # Extract datamodule configuration
        dm_config = config['datamodule']
        
        # Set up random seed
        seed = dm_config.get('seed')
        if seed is None:
            seed = random.randint(0, 10000)
        
        # Initialize the parent class with all the configuration
        super().__init__(
            root=root,
            val_root=val_root,
            num_samples=dm_config['num_samples'],
            img_res=dm_config['image_size'][0],  # Assuming square images
            bg_color_sampler_dict=config['bg_color_sampler'],
            use_worley_sampler=dm_config['use_worley_sampler'],
            use_grf_sampler=dm_config['use_grf_sampler'],
            worley_sampler_dict=config['worley_sampler'],
            mandelbulb_sampler=config['mandelbulb_sampler'],
            batch_size=dm_config['batch_size'],
            num_workers=dm_config['num_workers'],
            shuffle=dm_config['shuffle'],
            seed=seed,
            shaders=config['shaders'],
        )
